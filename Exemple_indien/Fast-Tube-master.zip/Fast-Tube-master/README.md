#Fast Tube
Fast Tube is a Java Application that allows people to smoothly use London underground by
efficiently planning their journey. It uses Dijkstra's algorithm to find shortest route to destination. The app also maps the shortest route and calculates total distance of journey and time taken depending on Peak and Off-Peak hours. Development involved usage of official Inter Station Database of London Underground provided by Travel For London (TFL)
