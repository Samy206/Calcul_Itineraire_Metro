
public class PredPointer {

	Node node;
	Node link;
	PredPointer(Node node,Node link) {
		this.node = node;
		this.link = link;
	}
}
